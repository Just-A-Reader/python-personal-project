from tkinter import PhotoImage
from turtle import Turtle, Screen, Shape
import turtle

def createPen(colour):
    pen = turtle.Turtle()
    pen.hideturtle()
    pen.color(colour)
    pen.penup()
    return pen


wn = turtle.Screen()
wn.title("Horizon - Historical")
wn.bgcolor("#D8D2C6")
screen = Screen()


#LOCATION 1 BACKGROUND
smaller = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\historical page\\parisbg.png").zoom(3, 3)
smaller = smaller.subsample(2, 2)
#new_image = image.zoom(3, 3)
#new_image = new_image.subsample(2, 2)

screen.addshape("smaller", Shape("image", smaller))
par = Turtle("smaller")
par.penup()
par.speed(1000)
par.goto(-230,-20)
par.stamp()
par.hideturtle()


#LOCATION 2 BACKGROUND
smallera = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\historical page\\romebg.png").zoom(3, 3)
smallera = smallera.subsample(2, 2)

screen.addshape("smallera", Shape("image", smallera))
rome = Turtle("smallera")
rome.penup()
rome.speed(1000)
rome.goto(230,-20)
rome.stamp()
rome.hideturtle()


#PAGE TITLE
smallerb = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\historical page\\Historical (1).png").subsample(2,2)

screen.addshape("smallerb", Shape("image", smallerb))
rome = Turtle("smallerb")
rome.penup()
rome.speed(1000)
rome.goto(0,275)
rome.stamp()
rome.hideturtle()


#LOCATION 1 NAME
smallerc = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\historical page\\paris france.png")

screen.addshape("smallerc", Shape("image", smallerc))
rome = Turtle("smallerc")
rome.penup()
rome.speed(1000)
rome.goto(-240,185)
rome.stamp()
rome.hideturtle()

#LOCATION 1 DESCRIPTION
smallerd = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\historical page\\the city of love, rich culture, french language, fashion and art.png")

screen.addshape("smallerd", Shape("image", smallerd))
rome = Turtle("smallerd")
rome.penup()
rome.speed(1000)
rome.goto(-260,145)
rome.stamp()
rome.hideturtle()

#LOCATION 1 VIEW MORE
smallere = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\historical page\\View More . . ..png")
screen.addshape("smallere", Shape("image", smallere))
rome = Turtle("smallere")
rome.penup()
rome.speed(1000)
rome.goto(-75,185)
rome.stamp()
rome.hideturtle()

#LOCATION 1 SQUARE 1
smallerf = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\historical page\\la seine.png")
screen.addshape("smallerf", Shape("image", smallerf))
rome = Turtle("smallerf")
rome.penup()
rome.speed(1000)
rome.goto(-365,-170)
rome.stamp()
rome.hideturtle()

#LOCATION 1 SQUARE 2
smallerg = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\historical page\\eiffel tower.png")
screen.addshape("smallerg", Shape("image", smallerg))
rome = Turtle("smallerg")
rome.penup()
rome.speed(1000)
rome.goto(-228,-170)
rome.stamp()
rome.hideturtle()

#LOCATION 1 SQUARE 3
smallerh = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\historical page\\louvre.png")
screen.addshape("smallerh", Shape("image", smallerh))
rome = Turtle("smallerh")
rome.penup()
rome.speed(1000)
rome.goto(-89,-188)
rome.stamp()
rome.hideturtle()



#LOCATION 2 NAME
#LOCATION 2 DESCRIPTION
#LOCATION 2 VIEW MORE
#LOCATION 2 SQUARE 1
#LOCATION 2 SQUARE 2
#LOCATION 2 SQUARE 3

wn.mainloop()