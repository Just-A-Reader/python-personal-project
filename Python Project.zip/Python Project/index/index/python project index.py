from tkinter import PhotoImage
from turtle import Turtle, Screen, Shape
import turtle

def createPen(colour):
    pen = turtle.Turtle()
    pen.hideturtle()
    pen.color(colour)
    pen.penup()
    return pen


wn = turtle.Screen()
wn.register_shape("C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\image 12 (3).gif")
wn.title("Horizon")
wn.bgpic("C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\image 12 (3).gif")
wn.bgcolor("black")
screen = Screen()

smaller = PhotoImage(file="C:\\Users\\iCan Student\Desktop\\Everything\\Coding\\Python Project\\index\\index\\logo.gif").subsample(2, 2)

screen.addshape("smaller", Shape("image", smaller))
logo = Turtle("smaller")
logo.penup()
logo.speed(10000)
logo.goto(0,250)
logo.stamp()
logo.hideturtle()



smaller1 = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\vacation.gif").subsample(2, 2)

screen.addshape("smaller1", Shape("image", smaller1))
vaca = Turtle("smaller1")
vaca.penup()
vaca.speed(10000)
vaca.goto(-200,100)
vaca.stamp()
vaca.hideturtle()


smaller2 = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\city.gif").subsample(2, 2)

screen.addshape("smaller2", Shape("image", smaller2))
city = Turtle("smaller2")
city.penup()
city.speed(10000)
city.goto(-200,0)
city.stamp()
city.hideturtle()



smaller3 = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\country side.gif").subsample(2, 2)

screen.addshape("smaller3", Shape("image", smaller3))
cs = Turtle("smaller3")
cs.penup()
cs.speed(10000)
cs.goto(-200,-100)
cs.stamp()
cs.hideturtle()



smaller4 = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\historical.gif").subsample(2, 2)

screen.addshape("smaller4", Shape("image", smaller4))
his = Turtle("smaller4")
his.penup()
his.speed(10000)
his.goto(-200,-200)
his.stamp()
his.hideturtle()



smaller5 = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\nature.gif").subsample(2, 2)

screen.addshape("smaller5", Shape("image", smaller5))
nature = Turtle("smaller5")
nature.penup()
nature.speed(10000)
nature.goto(200,100)
nature.stamp()
nature.hideturtle()




smaller6 = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\ocean side.gif").subsample(2, 2)

screen.addshape("smaller6", Shape("image", smaller6))
oc = Turtle("smaller6")
oc.penup()
oc.speed(10000)
oc.goto(200,0)
oc.stamp()
oc.hideturtle()




smaller7 = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\party.gif").subsample(2, 2)

screen.addshape("smaller7", Shape("image", smaller7))
party = Turtle("smaller7")
party.penup()
party.speed(10000)
party.goto(200,-100)
party.stamp()
party.hideturtle()




smaller8 = PhotoImage(file="C:\\Users\\iCan Student\\Desktop\\Everything\\Coding\\Python Project\\index\\index\\view all.gif").subsample(2, 2)

screen.addshape("smaller8", Shape("image", smaller8))
view = Turtle("smaller8")
view.penup()
view.speed(10000)
view.goto(200,-200)
view.stamp()
view.hideturtle()




wn.mainloop()